#pragma once
#include "GeneralOfDepartment.h"

class Manager :public Personal
{
private:
	Foreman** listOfForemans = nullptr;

public:
	int numberOfForemans;

	~Manager() override;

	Manager(Worker& worker)
		:Personal(worker.getFio(), worker.getAge(), worker.getBaseValue()) {
		worker.setPost(arrayOfPosts[MANAGER]);
		numberOfForemans = 0;
	}

	Foreman** getListOfForemans() {
		return listOfForemans;
	}

	void extendListOfForemans(int capacity);

	void addNewForeman(Foreman& foreman);

	int getNumberOfForemans() {
		return numberOfForemans;
	}

	float calculateSalary() const override;
	void printInfoAboutPersonal() const override;
	float getAverageKoef()const override;
};

