#include "Detail.h"

Detail::Detail(const char* name, int normRate, float factRate) {
	size_t len = strlen(name) + 1;
	_name = new char[len];
	strcpy_s(_name, len, name);
		this->normRate = normRate;
		this->factRate = factRate;
		this->koef = factRate / normRate;
}

Detail::~Detail()
{
	delete[] _name;
	cout << "Detail dtor" << endl;
}
