#pragma once
#include "Worker.h"
class Engineer:public Personal
{
private:
	Worker** listOfWorkers = nullptr;

public:
	int numberOfWorkers;

	~Engineer() override;

	Engineer(const char* fio, int age, int BaseValue);

	Worker** getListOfWorkers() {
		return listOfWorkers;
	};

	void extendListOfWorkers(int capacity);

	void addNewWorker(Worker& worker);

	int getNumberOfWorkers() {
		return numberOfWorkers;
	}

	float calculateSalary() const override;
	void printInfoAboutPersonal() const override;
	float getAverageKoef() const override;
};

