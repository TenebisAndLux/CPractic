#pragma once
#include "Engineer.h"

class Foreman: public Personal
{
private:
	Engineer** listOfEngineers = nullptr;

public:
	int numberOfEngineers;

	~Foreman() override;

	Foreman(const char* fio, int age, int BaseValue);

	Engineer** getListOfEngineers() {
		return listOfEngineers;
	}

	int getNumberOfEngineers() {
		return numberOfEngineers;
	}

	void extendListOfEngineers(int capacity);
	void addNewEngineer(Engineer& engineer);

	float calculateSalary() const override;
	void printInfoAboutPersonal() const override;
	float getAverageKoef() const override;
};

