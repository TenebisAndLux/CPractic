#pragma once
#include <stdlib.h>
#include "Detail.h"

using namespace std;

static const char* arrayOfPosts[]
{ "Default",
  "Worker",
  "Engineer",
  "Foreman",
  "Manager"
};

enum posts {
	DEFAULT,
	WORKER,
	ENGINEER,
	FOREMAN,
	MANAGER
};

class Personal
{
private:
	int _BaseValue;
	int _age;
	char* _fio = nullptr;
	const char* _post = nullptr;

public:
	virtual void printInfoAboutPersonal() const;

	virtual ~Personal();
	virtual float getBaseValue() const;
	virtual float getAverageKoef() const = 0;

	virtual const char* getPost() const;
	
	void setPost(const char* post){
		this->_post = post;
	}
	virtual float calculateSalary() const;

	Personal(const char* fio, int age, int BaseValue);
	
	char* getFio() {
		return _fio;
	}

	/*void setFio(char* fio) {
		this->_fio = fio;
	}*/

	void setBaseValue(int BaseValue) {
		this->_BaseValue = BaseValue;
	}

	int getAge() {
		return _age;
	}

	void setAge(int age) {
		this->_age = age;
	}
};