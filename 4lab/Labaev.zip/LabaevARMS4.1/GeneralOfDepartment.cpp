#include "GeneralOfDepartment.h"

Foreman::~Foreman()
{
	for (size_t i = 0; i < numberOfEngineers; i++) {
		delete	listOfEngineers[i];
	}
	delete[] listOfEngineers;

	cout << "Foreman dtor" << endl;
}

Foreman::Foreman(const char* fio, int age, int BaseValue)
	:Personal(fio, age, BaseValue) {
		this->setPost(arrayOfPosts[FOREMAN]);
		numberOfEngineers = 0;
}

void Foreman::printInfoAboutPersonal() const{
	
	Personal::printInfoAboutPersonal();

	for (int i = 0; i < numberOfEngineers; i++) {

		cout << "Engineer: " << endl;
		cout << "FIO: " << listOfEngineers[i]->getFio() << endl;
		cout << "Age: " << listOfEngineers[i]->getAge() << endl;
		cout << "Slary: ";
		cout << listOfEngineers[i]->calculateSalary() << endl;
		cout << endl;
	}

	cout << endl;
}

void Foreman::extendListOfEngineers(int capacity)
{
	if (capacity <= numberOfEngineers) {
		return;
	}
	else {
		Engineer** newListOfEngineer = new Engineer * [capacity];
		for (int i = 0; i < numberOfEngineers; i++) {
			newListOfEngineer[i] = listOfEngineers[i];
		}
		delete[] listOfEngineers;
		listOfEngineers = newListOfEngineer;
	}
}

void Foreman::addNewEngineer(Engineer& engineer)
{
	this->extendListOfEngineers(numberOfEngineers + 1);
	this->listOfEngineers[numberOfEngineers] = &engineer;
	numberOfEngineers++;
}

float Foreman::getAverageKoef() const {

	float averageKoef = 0.0f;
	float summaryKoef = 0.0f;

	for (int i = 0; i < numberOfEngineers; i++) {
		summaryKoef += listOfEngineers[i]->getAverageKoef();
	}

	averageKoef = summaryKoef / numberOfEngineers;
	return averageKoef;
}

float Foreman::calculateSalary()  const{
	float averageKoef = 0.0f;

	averageKoef = this->getAverageKoef();

	float surchargeMultiplier = 1.0f;
	if (averageKoef > 1.3) {
		surchargeMultiplier = 1.5f;
	}
	else if (averageKoef > 1.1) {
		surchargeMultiplier = 1.25f;
	}
	
	return getBaseValue() * surchargeMultiplier;
}
