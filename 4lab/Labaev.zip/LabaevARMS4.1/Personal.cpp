#include "Personal.h"

void Personal::printInfoAboutPersonal() const
{
	cout << "Job title: " << _post << endl;
	cout << "FIO: " << _fio << endl;
	cout << "Age: " << _age << endl;
	cout << "Salary: " << calculateSalary() << endl;
	cout << endl;

	cout << "Details for employee: " << endl;
	cout << endl;
}

Personal::~Personal()
{
	//delete[] _fio;
	//delete[] _post;
	cout << "Personal dtor" << endl;
}

float Personal::getBaseValue() const
{
	return _BaseValue;
}

const char* Personal::getPost() const
{
	return _post;
}

float Personal::calculateSalary() const{
	
	return getAverageKoef() * getBaseValue();

}

Personal::Personal(const char* fio, int age, int BaseValue)
	:_age(age),_BaseValue(BaseValue)
{
	size_t len = strlen(fio) + 1;
	_fio = new char[len];
	strcpy_s(_fio, len, fio);
	this->_post = arrayOfPosts[DEFAULT];
}
