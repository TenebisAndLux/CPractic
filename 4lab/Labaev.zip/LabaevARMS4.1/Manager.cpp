#include "Manager.h"

Manager::~Manager(){

	for (size_t i = 0; i < numberOfForemans; i++) {
		delete	listOfForemans[i];
	}
	delete[] listOfForemans;

	cout << "Manager dtor" << endl;
}

void Manager::extendListOfForemans(int capacity){
	if (capacity <= numberOfForemans) {
		return;
	}
	else {
		Foreman** newListOfForemans = new Foreman * [capacity];
		for (int i = 0; i < numberOfForemans; i++) {
			newListOfForemans[i] = listOfForemans[i];
		}
		delete[] listOfForemans;
		listOfForemans = newListOfForemans;
	}
}

void Manager::addNewForeman(Foreman& foreman){
	this->extendListOfForemans(numberOfForemans + 1);
	this->listOfForemans[numberOfForemans] = &foreman;
	numberOfForemans++;
}

void Manager::printInfoAboutPersonal() const {

	Personal::printInfoAboutPersonal();

	for (int i = 0; i < numberOfForemans; i++) {

		cout << "Foreman: " << endl;
		cout << "FIO: " << listOfForemans[i]->getFio() << endl;
		cout << "Age: " << listOfForemans[i]->getAge() << endl;
		cout << "Slary: ";
		cout << listOfForemans[i]->calculateSalary() << endl;
		cout << endl;
	}

	cout << endl;
}

float Manager::getAverageKoef() const {
	return getAverageKoef();
}

float Manager::calculateSalary()  const {
	return 1.6f * getBaseValue();
}
