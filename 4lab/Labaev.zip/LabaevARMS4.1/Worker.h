#pragma once
#include "Detail.h"
#include "Personal.h"

class Worker:public Personal
{private:
	Detail** listOfDetails;

public:
	int numberOfDetails;

	~Worker() override;

	Worker(const char* name, int age, int BaseValue);

	void extendListOfDetails(int capacity);

	void addNewDetail(Detail& detail);

	Detail** getListOfDetails() {
		return listOfDetails;
	};

	float getAverageKoef() const override;
	void printInfoAboutPersonal() const override;
};

